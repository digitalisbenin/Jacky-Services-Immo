
<!DOCTYPE html>
<html class="wide wow-animation" lang="fr">
  <head>
    <title>Jacky-Services-Immobiliers</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width height=device-height initial-scale=1.0 maximum-scale=1.0 user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <link rel="icon" href="site/images/logo3.jpg" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Work+Sans:300,400,500,700,800%7CPoppins:300,400,700">
    <link rel="stylesheet" href="site/css/bootstrap.css">
    <link rel="stylesheet" href="site/css/fonts.css">
    <link rel="stylesheet" href="site/css/style.css" id="main-styles-link">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}
      .tiktok-button {
        position: fixed;
        bottom: 20px; /* Ajuste la position verticale */
        right: 10px; /* Place-le à droite */
        background-color: #D3D3D3; /* Fond noir TikTok */
        padding: 10px;
        border-radius: 50%;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
        z-index: 999;
    }

    .tiktok-button img {
        width: 40px;
        height: 40px;
    }

    </style>
  </head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="site/images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-logo"><img src="site/images/logo3.jpg" alt="" width="151" height="44" srcset="site/images/logo3.jpg 2x"/>
      </div>
      <div class="preloader-body">
        <div id="loadingProgressG">
          <div class="loadingProgressG" id="loadingProgressG_1"></div>
        </div>
      </div>
    </div>
    <div class="page">
      <!-- Page Header-->
      <header class="section novi-background page-header">
        <!-- RD Navbar-->
        <div class="rd-navbar-wrap">
          <nav class="rd-navbar rd-navbar-corporate" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static" data-lg-stick-up="true" data-lg-stick-up-offset="118px" data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-xl-stick-up="true" data-xl-stick-up-offset="118px" data-xxl-layout="rd-navbar-static" data-xxl-device-layout="rd-navbar-static" data-xxl-stick-up-offset="118px" data-xxl-stick-up="true">
            <div class="rd-navbar-aside-outer" style="background-color:#0F056B;">
              <div class="rd-navbar-aside" >
                <!-- RD Navbar Panel-->
                <div class="rd-navbar-panel">
                  <!-- RD Navbar Toggle-->
                  <button class="rd-navbar-toggle" data-rd-navbar-toggle="#rd-navbar-nav-wrap-1"><span></span></button>
                  <!-- RD Navbar Brand-->
                  <a class="rd-navbar-brand" href="/"><img src="site/images/logo3.jpg" style=" border-radius: 50%;
                            width: 60px;
                            height: 60px;
                            object-fit: cover;" alt=" Logo" width="151" height="44" srcset="site/images/logo3.jpg 2x"/></a>
                </div>
                <div class="rd-navbar-collapse">
                  {{--  <button class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle="#rd-navbar-collapse-content-1"><span></span></button>  --}}
                  <div class="rd-navbar-collapse-content" id="rd-navbar-collapse-content-1">
                    <article class="unit align-items-center">
                      <div class="unit-left"><span style="color:#fff;"  class="icon novi-icon icon-md icon-modern mdi mdi-phone"></span></div>
                      <div class="unit-body">
                        <ul class="list-0">
                          <li><a class="link-default" style="color:#fff;" href="tel:#">(+229) 0140338964</a></li>
                          <li><a class="link-default" style="color:#fff;"  href="tel:#">(+229) 0161484370</a></li>
                        </ul>
                      </div>
                    </article>
                    <article class="unit align-items-center">
                      <div class="unit-left"><span style="color:#fff;" class="icon novi-icon icon-md icon-modern mdi mdi-map-marker"></span></div>
                      <div class="unit-body"><a class="link-default" style="color:#fff;"  href="tel:#">Bénin, Atlantique <br> TORI GARE CENTRE</a></div>
                    </article>
                    {{--  <a class="button button-gray-bordered button-winona" href="#">Request a call</a>  --}}
                  </div>
                </div>
              </div>
            </div>
            <div style="background-color:#000;"  class="rd-navbar-main-outer">
              <div class="rd-navbar-main">
                <div class="rd-navbar-nav-wrap" id="rd-navbar-nav-wrap-1">
                  <!-- RD Navbar Nav-->
                  <ul class="rd-navbar-nav">
                    <li class="rd-nav-item active"><a class="rd-nav-link" href="/">Accueil</a>
                    </li>
                    <li class="rd-nav-item"><a class="rd-nav-link" href="/a-propos">Qui sommes-nous</a></li>

                    <li class="rd-nav-item"><a class="rd-nav-link" href="parcelle">Nos parcelles</a>
                    </li>
                    <li class="rd-nav-item"><a class="rd-nav-link" href="/habitations">Nos habitations</a>
                    </li>
                    {{--  <li class="rd-nav-item"><a class="rd-nav-link" href="about-us.html">A propos</a>
                    </li>
                     --}}
                    <li class="rd-nav-item"><a class="rd-nav-link" href="contact">Contacts</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>
      <section class="section novi-background breadcrumbs-custom bg-image context-dark" style="background-image: url(site/images/contact.jpg);">
        <div class="breadcrumbs-custom-inner">
          <div class="container breadcrumbs-custom-container">
            <div class="breadcrumbs-custom-main">
              <h6 class="breadcrumbs-custom-subtitle title-decorated">Contacts</h6>
              <h2 class="text-uppercase breadcrumbs-custom-title">Contacts</h2>
            </div>
            <ul class="breadcrumbs-custom-path">
              <li><a href="/">Accueil</a></li>
              <li class="active">Contacts</li>
            </ul>
          </div>
        </div>
      </section>
      <section class="section novi-background section-sm">
        <div class="container">
          <div class="layout-bordered">
            <div class="layout-bordered-item wow-outer">
              <div class="layout-bordered-item-inner wow slideInUp">
                <div class="icon novi-icon icon-lg mdi mdi-phone text-primary"></div>
                <ul class="list-0">
                  <li><a class="link-default" href="tel:#">(+229) 0140338964</a></li>
                  <li><a class="link-default" href="tel:#">(+229) 0161484370</a></li>
                </ul>
              </div>
            </div>
            <div class="layout-bordered-item wow-outer">
              <div class="layout-bordered-item-inner wow slideInUp">
                <div class="icon novi-icon icon-lg mdi mdi-email text-primary"></div><a class="link-default" href="mailto:#">jackyimmopro@gmail.com  </a>
              </div>
            </div>
            <div class="layout-bordered-item wow-outer">
              <div class="layout-bordered-item-inner wow slideInUp">
                <div class="icon novi-icon icon-lg mdi mdi-map-marker text-primary"></div><a class="link-default" href="#">Bénin, Atlantique
                  TORI GARE CENTRE</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section novi-background bg-gray-100">
        <div class="range justify-content-xl-between">
          <div class="cell-xl-6 align-self-center container">
            <div class="row">
              <div class="col-lg-9 cell-inner">
                <div class="section-lg">
                  <h3 class="text-uppercase wow-outer"><span class="wow slideInDown">Contactez-nous</span></h3>
                  <!-- RD Mailform-->
                  <form class=""  method="post" action="{{ route('contact.send') }}">
                    @csrf
                    <div class="row row-10">
                      <div class="col-md-6 wow-outer">
                        <div class="form-wrap wow fadeSlideInUp">
                          <label class="form-label-outside" for="contact-first-name">Nom</label>
                          <input class="form-input" id="contact-first-name" type="text" name="name"  required>
                        </div>
                      </div>
                      <div class="col-md-6 wow-outer">
                        <div class="form-wrap wow fadeSlideInUp">
                          <label class="form-label-outside" for="contact-last-name">Prénoms</label>
                          <input class="form-input" id="contact-last-name" type="text" name="prenom" required>
                        </div>
                      </div>
                      <div class="col-md-6 wow-outer">
                        <div class="form-wrap wow fadeSlideInUp">
                          <label class="form-label-outside" for="contact-email">E-mail</label>
                          <input class="form-input" id="contact-email" type="email" name="email" required>
                        </div>
                      </div>
                      <div class="col-md-6 wow-outer">
                        <div class="form-wrap wow fadeSlideInUp">
                          <label class="form-label-outside" for="contact-phone">Téléphone</label>
                          <input class="form-input" id="contact-phone" type="text" name="phone" >
                        </div>
                      </div>
                      <div class="col-12 wow-outer">
                        <div class="form-wrap wow fadeSlideInUp">
                          <label class="form-label-outside" for="contact-message">Votre Message</label>
                          <textarea class="form-input" id="contact-message" name="message"  required></textarea>
                        </div>
                      </div>
                    </div>
                    <div style="text-align:right; margin-top:9px;" class="group  ">
                      <div class="wow-outer ">
                        <button style="text-align:right;" class="button button-primary  wow slideInLeft" type="submit">Envoyer</button>
                      </div>


                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="cell-xl-5 height-fill wow fadeIn">
            {{--  <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3958.024159551146!2d1.8472221999999998!3d7.238083299999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zN8KwMTQnMTcuMSJOIDHCsDUwJzUwLjAiRQ!5e0!3m2!1sfr!2sbj!4v1743764759488!5m2!1sfr!2sbj" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>  --}}
            <div class="google-map-container">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3958.024159551146!2d1.8472221999999998!3d7.238083299999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zN8KwMTQnMTcuMSJOIDHCsDUwJzUwLjAiRQ!5e0!3m2!1sfr!2sbj!4v1743764759488!5m2!1sfr!2sbj"
                  width="680" height="650" frameborder="0" style="border:0" allowfullscreen>
                </iframe>
              </div>

            {{--  <div class="google-map-container" data-zoom="5" data-icon="images/gmap_marker.png" data-icon-active="images/gmap_marker.png" data-center="9870 St Vincent Place, Glasgow, DC 45 Fr 45." data-styles="[{&quot;featureType&quot;:&quot;water&quot;,&quot;elementType&quot;:&quot;geometry&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#e9e9e9&quot;},{&quot;lightness&quot;:17}]},{&quot;featureType&quot;:&quot;landscape&quot;,&quot;elementType&quot;:&quot;geometry&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#f5f5f5&quot;},{&quot;lightness&quot;:20}]},{&quot;featureType&quot;:&quot;road.highway&quot;,&quot;elementType&quot;:&quot;geometry.fill&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#ffffff&quot;},{&quot;lightness&quot;:17}]},{&quot;featureType&quot;:&quot;road.highway&quot;,&quot;elementType&quot;:&quot;geometry.stroke&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#ffffff&quot;},{&quot;lightness&quot;:29},{&quot;weight&quot;:0.2}]},{&quot;featureType&quot;:&quot;road.arterial&quot;,&quot;elementType&quot;:&quot;geometry&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#ffffff&quot;},{&quot;lightness&quot;:18}]},{&quot;featureType&quot;:&quot;road.local&quot;,&quot;elementType&quot;:&quot;geometry&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#ffffff&quot;},{&quot;lightness&quot;:16}]},{&quot;featureType&quot;:&quot;poi&quot;,&quot;elementType&quot;:&quot;geometry&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#f5f5f5&quot;},{&quot;lightness&quot;:21}]},{&quot;featureType&quot;:&quot;poi.park&quot;,&quot;elementType&quot;:&quot;geometry&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#dedede&quot;},{&quot;lightness&quot;:21}]},{&quot;elementType&quot;:&quot;labels.text.stroke&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;on&quot;},{&quot;color&quot;:&quot;#ffffff&quot;},{&quot;lightness&quot;:16}]},{&quot;elementType&quot;:&quot;labels.text.fill&quot;,&quot;stylers&quot;:[{&quot;saturation&quot;:36},{&quot;color&quot;:&quot;#333333&quot;},{&quot;lightness&quot;:40}]},{&quot;elementType&quot;:&quot;labels.icon&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;transit&quot;,&quot;elementType&quot;:&quot;geometry&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#f2f2f2&quot;},{&quot;lightness&quot;:19}]},{&quot;featureType&quot;:&quot;administrative&quot;,&quot;elementType&quot;:&quot;geometry.fill&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#fefefe&quot;},{&quot;lightness&quot;:20}]},{&quot;featureType&quot;:&quot;administrative&quot;,&quot;elementType&quot;:&quot;geometry.stroke&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#fefefe&quot;},{&quot;lightness&quot;:17},{&quot;weight&quot;:1.2}]}]">
              <div class="google-map"></div>
              <ul class="google-map-markers">
                <li data-location="9870 St Vincent Place, Glasgow, DC 45 Fr 45." data-description="9870 St Vincent Place, Glasgow"></li>
              </ul>
            </div>  --}}
          </div>
        </div>
      </section>


      <footer class="section novi-background footer-advanced bg-gray-700">

        {{--  <div class="footer-advanced-aside">  --}}
          {{--  <div class="container">
            <div class="footer-advanced-layout">
              <div>
                <ul class="list-nav">
                  <li><a href="/">Accueil</a></li>
                  <li><a href="a-propos">Qui sommes-nous</a></li>
                  <li><a href="parcelle">Nos parcelles</a></li>
                  <li><a href="habitations">Nos habitations</a></li>

                  <li><a href="contact">Contacts</a></li>
                </ul>
              </div>
              <div>
                <ul class="foter-social-links list-inline list-inline-md">
                  <li><a class="icon novi-icon icon-sm link-default mdi mdi-facebook" target="_blank" href="https://www.facebook.com/profile.php?id=61550218523699"></a></li>


                    <li>
                        <a class="fa-brands fa-tiktok text-white" target="_blank" href="https://www.tiktok.com/@jackyservicesimmo?_t=ZM-8v9OYgrDtvp&_r=1"></a>
                    </li>

                    <li>
                            <a class="icon novi-icon icon-sm link-default mdi mdi-whatsapp" href="https://wa.me/22940338964" target="_blank"></a>
                        </li>

                   <li><a class="icon novi-icon icon-sm link-default mdi mdi-twitter" href="#"></a></li>
                    <li><a class="icon novi-icon icon-sm link-default mdi mdi-instagram" href="#"></a></li>
                  <li><a class="icon novi-icon icon-sm link-default mdi mdi-google" href="#"></a></li>  -
                  <li><a class="icon novi-icon icon-sm link-default mdi mdi-linkedin" href="#"></a></li>
                </ul>
              </div>
            </div>
          </div>
            </div>  --}}

        <div class="footer-advanced-aside">
          <div class="container">
            <div class="footer-advanced-layout">
                <a style="margin-left:30px;"class="brand " href="login"><img src="{{asset('site/images/logo3-1.jpg')}}" style=" border-radius: 50%;
                           margin-left:45px; width: 60px;
                            height: 60px;
                            object-fit: cover;" alt=" logo tettdd" width="115" height="34" srcset="site/images/logo3-1.jpg 2x"/></a>

                             <ul class="foter-social-links list-inline list-inline-md">
                  <li><a class="icon novi-icon icon-sm link-default mdi mdi-facebook" target="_blank" href="https://www.facebook.com/profile.php?id=61550218523699"></a></li>


                    <li>
                        <a class="fa-brands fa-tiktok text-white" target="_blank" href="https://www.tiktok.com/@jackyservicesimmo?_t=ZM-8v9OYgrDtvp&_r=1"></a>
                    </li>

                    <li>
                            <a class="icon novi-icon icon-sm link-default mdi mdi-whatsapp" href="https://wa.me/22940338964" target="_blank"></a>
                        </li>
                        <li>
                            <a class="icon novi-icon icon-sm link-default" href="https://web53.lws-hosting.com:2096/cpsess6637140572/3rdparty/roundcube/?_task=mail&_mbox=INBOX" target="_blank">webmail</a>
                        </li>
                   {{--  <li><a class="icon novi-icon icon-sm link-default mdi mdi-twitter" href="#"></a></li>
                    <li><a class="icon novi-icon icon-sm link-default mdi mdi-instagram" href="#"></a></li>
                  <li><a class="icon novi-icon icon-sm link-default mdi mdi-google" href="#"></a></li>  -
                  <li><a class="icon novi-icon icon-sm link-default mdi mdi-linkedin" href="#"></a></li>  --}}
                </ul>
              <!-- Rights-->
              <p class="rights"><span>&copy;&nbsp;</span><span class="copyright-year"></span>. Tous droit réservées. Designé Par  <a href="https://digitalis-benin.com/">Digitalis</a></p>
            </div>
          </div>
        </div>
    </footer>
      <a href="https://www.tiktok.com/@jackyservicesimmo?_t=ZM-8v9OYgrDtvp&_r=1"
   class="tiktok-button"
   target="_blank">
    <img src="https://upload.wikimedia.org/wikipedia/en/a/a9/TikTok_logo.svg" alt="TikTok">
</a>
    </div>
    <!-- Global Mailform Output-->

    <!-- Javascript-->
    <script type="text/javascript">
      (function () {
          var options = {
              whatsapp: "22940338964", // Remplace avec ton numéro WhatsApp
              call_to_action: "",
              position: "left", // Position du bouton (left ou right)
          };
          var proto = document.location.protocol,
              host = "getbutton.io",
              url = proto + "//static." + host;
          var s = document.createElement("script");
          s.type = "text/javascript";
          s.async = true;
          s.src = url + "/widget-send-button/js/init.js";
          s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
          document.getElementsByTagName("body")[0].appendChild(s);
      })();
  </script>
    <script src="site/js/core.min.js"></script>
    <script src="site/js/script.js"></script>
  </body>
</html>
